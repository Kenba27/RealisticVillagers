package net.wesjd.anvilgui;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;

/**
 * Minimal replacement of net.wesjd:anvilgui that only uses the Bukkit/Paper API (no NMS),
 * so it keeps working on any version that supports Player#openAnvil (Paper).
 * Only the subset of the API used by RealisticVillagers is implemented.
 */
public final class AnvilGUI {

    private static final Map<UUID, AnvilGUI> OPEN = new ConcurrentHashMap<>();
    private static final Listener LISTENER = new AnvilListener();
    private static volatile boolean registered;

    private final Player player;
    private final Plugin plugin;
    private final String text;
    private final BiFunction<Integer, StateSnapshot, List<ResponseAction>> onClick;
    private final Consumer<StateSnapshot> onClose;
    private InventoryView view;

    private AnvilGUI(Builder builder, Player player) {
        this.player = player;
        this.plugin = builder.plugin;
        this.text = builder.text;
        this.onClick = builder.onClick;
        this.onClose = builder.onClose;
        open(builder);
    }

    public static final class Slot {
        public static final int INPUT_LEFT = 0;
        public static final int INPUT_RIGHT = 1;
        public static final int OUTPUT = 2;

        private Slot() {
        }
    }

    public interface ResponseAction extends BiConsumer<AnvilGUI, Player> {

        static ResponseAction close() {
            return (gui, player) -> gui.closeInventory();
        }
    }

    public static final class StateSnapshot {

        private final Player player;
        private final String text;

        private StateSnapshot(Player player, String text) {
            this.player = player;
            this.text = text;
        }

        public Player getPlayer() {
            return player;
        }

        public String getText() {
            return text;
        }
    }

    public static final class Builder {

        private Plugin plugin;
        private String title = "Repair & Name";
        private String text = "";
        private ItemStack itemLeft;
        private BiFunction<Integer, StateSnapshot, List<ResponseAction>> onClick;
        private Consumer<StateSnapshot> onClose;

        public Builder plugin(Plugin plugin) {
            this.plugin = plugin;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder text(String text) {
            this.text = text;
            return this;
        }

        public Builder itemLeft(ItemStack item) {
            this.itemLeft = item;
            return this;
        }

        public Builder onClick(BiFunction<Integer, StateSnapshot, List<ResponseAction>> onClick) {
            this.onClick = onClick;
            return this;
        }

        public Builder onClose(Consumer<StateSnapshot> onClose) {
            this.onClose = onClose;
            return this;
        }

        public AnvilGUI open(Player player) {
            return new AnvilGUI(this, player);
        }
    }

    public void closeInventory() {
        player.closeInventory();
    }

    private void open(Builder builder) {
        register(plugin);

        try {
            Method method = Player.class.getMethod("openAnvil", Location.class, boolean.class);
            Object result = method.invoke(player, new Object[]{null, true});
            if (!(result instanceof InventoryView opened)) {
                plugin.getLogger().severe("Couldn't open the anvil GUI for " + player.getName() + ".");
                return;
            }
            this.view = opened;
        } catch (Throwable throwable) {
            plugin.getLogger().severe("Couldn't open the anvil GUI for " + player.getName() + ": " + throwable);
            return;
        }

        try {
            Method setTitle = InventoryView.class.getMethod("setTitle", String.class);
            setTitle.invoke(view, builder.title);
        } catch (Throwable ignored) {
            // Keep the default title.
        }

        ItemStack left = builder.itemLeft != null ? builder.itemLeft.clone() : new ItemStack(Material.PAPER);
        ItemMeta meta = left.getItemMeta();
        if (meta != null && text != null && !text.isEmpty()) {
            meta.setDisplayName(text);
            left.setItemMeta(meta);
        }
        view.getTopInventory().setItem(Slot.INPUT_LEFT, left);

        OPEN.put(player.getUniqueId(), this);
    }

    private static synchronized void register(Plugin plugin) {
        if (registered) return;
        Bukkit.getPluginManager().registerEvents(LISTENER, plugin);
        registered = true;
    }

    private boolean isSame(Inventory inventory) {
        return view != null && inventory != null && inventory.equals(view.getTopInventory());
    }

    private static String renameText(InventoryView view) {
        // Newer versions: AnvilView#getRenameText(). Older: AnvilInventory#getRenameText().
        for (String className : new String[]{"org.bukkit.inventory.view.AnvilView", "org.bukkit.inventory.AnvilInventory"}) {
            try {
                Class<?> clazz = Class.forName(className);
                Object target = className.endsWith("AnvilView") ? view : view.getTopInventory();
                if (!clazz.isInstance(target)) continue;
                Object result = clazz.getMethod("getRenameText").invoke(target);
                return result instanceof String string ? string : null;
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    private static void setRepairCost(InventoryView view, int cost) {
        try {
            Class<?> clazz = Class.forName("org.bukkit.inventory.view.AnvilView");
            if (clazz.isInstance(view)) clazz.getMethod("setRepairCost", int.class).invoke(view, cost);
        } catch (Throwable ignored) {
        }
    }

    private StateSnapshot snapshot() {
        String current = renameText(view);
        if (current == null || current.isEmpty()) current = text == null ? "" : text;
        return new StateSnapshot(player, current);
    }

    private static final class AnvilListener implements Listener {

        private static AnvilGUI get(Player player, Inventory inventory) {
            AnvilGUI gui = OPEN.get(player.getUniqueId());
            return gui != null && gui.isSame(inventory) ? gui : null;
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onPrepare(PrepareAnvilEvent event) {
            if (!(event.getView().getPlayer() instanceof Player player)) return;

            AnvilGUI gui = get(player, event.getView().getTopInventory());
            if (gui == null) return;

            ItemStack left = event.getView().getTopInventory().getItem(Slot.INPUT_LEFT);
            ItemStack result = left != null ? left.clone() : new ItemStack(Material.PAPER);

            String current = renameText(event.getView());
            ItemMeta meta = result.getItemMeta();
            if (meta != null && current != null && !current.isEmpty()) {
                meta.setDisplayName(current);
                result.setItemMeta(meta);
            }

            event.setResult(result);
            setRepairCost(event.getView(), 0);
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;

            AnvilGUI gui = get(player, event.getView().getTopInventory());
            if (gui == null) return;

            // Nothing can be taken or moved from/to this GUI.
            event.setCancelled(true);

            int slot = event.getRawSlot();
            if (slot < 0 || slot > Slot.OUTPUT || gui.onClick == null) return;

            List<ResponseAction> actions = gui.onClick.apply(slot, gui.snapshot());
            if (actions == null) actions = Collections.emptyList();
            for (ResponseAction action : actions) {
                action.accept(gui, player);
            }
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onDrag(InventoryDragEvent event) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            if (get(player, event.getView().getTopInventory()) != null) event.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.MONITOR)
        public void onClose(InventoryCloseEvent event) {
            if (!(event.getPlayer() instanceof Player player)) return;

            AnvilGUI gui = get(player, event.getView().getTopInventory());
            if (gui == null) return;

            OPEN.remove(player.getUniqueId(), gui);

            StateSnapshot snapshot = gui.snapshot();
            // Don't give the placeholder item back to the player.
            gui.view.getTopInventory().clear();

            if (gui.onClose != null) gui.onClose.accept(snapshot);
        }
    }
}

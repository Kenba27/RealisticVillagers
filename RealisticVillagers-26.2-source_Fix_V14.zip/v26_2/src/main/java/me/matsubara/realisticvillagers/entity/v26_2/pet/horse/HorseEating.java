package me.matsubara.realisticvillagers.entity.v26_2.pet.horse;

import net.minecraft.world.item.ItemStack;

public interface HorseEating {

    void handleEating(ItemStack item);
}
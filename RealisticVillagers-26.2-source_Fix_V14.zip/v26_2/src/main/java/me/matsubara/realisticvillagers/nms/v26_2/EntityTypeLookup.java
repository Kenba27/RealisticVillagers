package me.matsubara.realisticvillagers.nms.v26_2;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;

import java.util.Optional;

// EntityType.byString was removed in 26.2.
public final class EntityTypeLookup {

    private EntityTypeLookup() {
    }

    public static Optional<EntityType<?>> byString(String name) {
        Identifier id = Identifier.tryParse(name);
        if (id == null) return Optional.empty();
        return BuiltInRegistries.ENTITY_TYPE.getOptional(id);
    }
}

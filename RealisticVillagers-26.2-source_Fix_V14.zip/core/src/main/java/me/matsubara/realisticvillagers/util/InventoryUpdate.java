/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2021 Matsubara
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package me.matsubara.realisticvillagers.util;

import com.cryptomorin.xseries.reflection.XReflection;
import com.cryptomorin.xseries.reflection.minecraft.MinecraftConnection;
import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import lombok.Getter;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.InventoryView;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.util.Locale;
import java.util.Set;

/**
 * A utility class for update the inventory of a player.
 * This is useful to change the title of an inventory.
 */
@SuppressWarnings({"ConstantConditions", "deprecation"})
public final class InventoryUpdate {

    // Classes.
    private static final Class<?> CRAFT_PLAYER;
    private static final Class<?> CHAT_MESSAGE;
    private static final Class<?> PACKET_PLAY_OUT_OPEN_WINDOW;
    private static final Class<?> I_CHAT_BASE_COMPONENT;
    private static final Class<?> CONTAINER;
    private static final Class<?> CONTAINERS;
    private static final Class<?> ENTITY_PLAYER;
    private static final Class<?> ENTITY_HUMAN;
    private static final Class<?> I_CHAT_MUTABLE_COMPONENT;

    // Methods.
    private static final MethodHandle getHandle;
    private static final MethodHandle getBukkitView;
    private static final MethodHandle literal;

    // Constructors.
    private static final MethodHandle chatMessage;
    private static final MethodHandle packetPlayOutOpenWindow;

    // Fields.
    private static final MethodHandle activeContainer;
    private static final MethodHandle windowId;

    private static final JavaPlugin PLUGIN = JavaPlugin.getProvidingPlugin(InventoryUpdate.class);
    private static final Set<String> UNOPENABLES = Sets.newHashSet("CRAFTING", "CREATIVE", "PLAYER");
    private static final boolean SUPPORTS_19 = XReflection.supports(19);
    private static final Object[] DUMMY_COLOR_MODIFIERS = new Object[0];

    static { // While we should use XReflection.ofMinecraft() instead of the deprecated methods, these will work for the moment.
        // Initialize classes.
        CRAFT_PLAYER = XReflection.getCraftClass("entity.CraftPlayer");
        CHAT_MESSAGE = SUPPORTS_19 ? null : XReflection.getNMSClass("network.chat", "ChatMessage");
        PACKET_PLAY_OUT_OPEN_WINDOW = Reflection.getNMSClass("network.protocol.game", "ClientboundOpenScreenPacket", "PacketPlayOutOpenWindow");
        I_CHAT_BASE_COMPONENT = Reflection.getNMSClass("network.chat", "Component", "IChatBaseComponent");
        // Check if we use containers, otherwise, can throw errors on older versions.
        CONTAINERS = useContainers() ? Reflection.getNMSClass("world.inventory", "MenuType", "Containers") : null;
        ENTITY_PLAYER = Reflection.getNMSClass("server.level", "ServerPlayer", "EntityPlayer");
        ENTITY_HUMAN = Reflection.getNMSClass("world.entity.player", "Player", "EntityHuman");
        CONTAINER = Reflection.getNMSClass("world.inventory", "AbstractContainerMenu", "Container");
        I_CHAT_MUTABLE_COMPONENT = SUPPORTS_19 ? Reflection.getNMSClass("network.chat", "MutableComponent", "IChatMutableComponent") : null;

        // Initialize methods.
        getHandle = Reflection.getMethod(CRAFT_PLAYER, "getHandle", MethodType.methodType(ENTITY_PLAYER));
        getBukkitView = Reflection.getMethod(CONTAINER, "getBukkitView", MethodType.methodType(InventoryView.class));
        literal = SUPPORTS_19 ? Reflection.getMethod(I_CHAT_BASE_COMPONENT, "b", MethodType.methodType(I_CHAT_MUTABLE_COMPONENT, String.class), true, true, "literal") : null;

        // Initialize constructors.
        chatMessage = SUPPORTS_19 ? null : Reflection.getConstructor(CHAT_MESSAGE, String.class, Object[].class);
        packetPlayOutOpenWindow =
                (useContainers()) ?
                        Reflection.getConstructor(PACKET_PLAY_OUT_OPEN_WINDOW, int.class, CONTAINERS, I_CHAT_BASE_COMPONENT) :
                        // Older versions use String instead of Containers, and require an int for the inventory size.
                        Reflection.getConstructor(PACKET_PLAY_OUT_OPEN_WINDOW, int.class, String.class, I_CHAT_BASE_COMPONENT, int.class);

        // Initialize fields.
        activeContainer = Reflection.getField(ENTITY_HUMAN, CONTAINER, "activeContainer", true, "bV", "bW", "bU", "bP", "containerMenu");
        windowId = Reflection.getField(CONTAINER, int.class, "windowId", true, "j", "containerId");
    }

    /**
     * Update the player inventory, so you can change the title.
     *
     * @param player   the player whose inventory will be updated.
     * @param newTitle the new title for the inventory.
     */
    @SuppressWarnings("UnstableApiUsage")
    public static void updateInventory(Player player, String newTitle) {
        Preconditions.checkArgument(player != null, "Cannot update inventory to null player.");
        Preconditions.checkArgument(newTitle != null, "The new title can't be null.");

        try {
            if (newTitle.length() > 32) {
                newTitle = newTitle.substring(0, 32);
            }

            if (XReflection.supports(20)) {
                InventoryView open = player.getOpenInventory();
                if (UNOPENABLES.contains(open.getType().name())) return;
                open.setTitle(newTitle);
                return;
            }

            // Get EntityPlayer from CraftPlayer.
            Object craftPlayer = CRAFT_PLAYER.cast(player);
            Object entityPlayer = getHandle.invoke(craftPlayer);

            // Create a new title.
            Object title;
            if (XReflection.supports(19)) {
                title = literal.invoke(newTitle);
            } else {
                title = chatMessage.invoke(newTitle, DUMMY_COLOR_MODIFIERS);
            }

            // Get activeContainer from EntityPlayer.
            Object activeContainer = InventoryUpdate.activeContainer.invoke(entityPlayer);

            // Get windowId from activeContainer.
            Integer windowId = (Integer) InventoryUpdate.windowId.invoke(activeContainer);

            // Get InventoryView from activeContainer.
            Object bukkitView = getBukkitView.invoke(activeContainer);
            if (!(bukkitView instanceof InventoryView)) return;

            // Avoiding pattern variable, since some people may be using an older version of java.
            //noinspection PatternVariableCanBeUsed
            InventoryView view = (InventoryView) bukkitView;
            InventoryType type = view.getTopInventory().getType();

            // Workbenchs and anvils can change their title since 1.14.
            if ((type == InventoryType.WORKBENCH || type == InventoryType.ANVIL) && !useContainers()) return;

            // You can't reopen crafting, creative and player inventory.
            if (UNOPENABLES.contains(type.name())) return;

            int size = view.getTopInventory().getSize();

            // Get container, check is not null.
            Containers container = Containers.getType(type, size);
            if (container == null) return;

            // If the container was added in a newer version than the current, return.
            if (container.getContainerVersion() > XReflection.MINOR_NUMBER && useContainers()) {
                PLUGIN.getLogger().warning("This container doesn't work on your current version.");
                return;
            }

            Object object;
            // Dispensers and droppers use the same container, but in previous versions, use a diferrent minecraft name.
            if (!useContainers() && container == Containers.GENERIC_3X3) {
                object = "minecraft:" + type.name().toLowerCase(Locale.ROOT);
            } else {
                object = container.getObject();
            }

            // Create packet.
            Object packet = useContainers() ?
                    packetPlayOutOpenWindow.invoke(windowId, object, title) :
                    packetPlayOutOpenWindow.invoke(windowId, object, title, size);

            // Send packet sync.
            MinecraftConnection.sendPacket(player, packet);

            // Update inventory.
            player.updateInventory();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    /**
     * Containers were added in 1.14, a String was used in previous versions.
     *
     * @return whether to use containers.
     */
    private static boolean useContainers() {
        return XReflection.MINOR_NUMBER > 13;
    }

    /**
     * An enum class for the necessary containers.
     */
    @Getter
    private enum Containers {
        GENERIC_9X1(14, "minecraft:chest", "CHEST"),
        GENERIC_9X2(14, "minecraft:chest", "CHEST"),
        GENERIC_9X3(14, "minecraft:chest", "CHEST", "ENDER_CHEST", "BARREL"),
        GENERIC_9X4(14, "minecraft:chest", "CHEST"),
        GENERIC_9X5(14, "minecraft:chest", "CHEST"),
        GENERIC_9X6(14, "minecraft:chest", "CHEST"),
        GENERIC_3X3(14, null, "DISPENSER", "DROPPER"),
        ANVIL(14, "minecraft:anvil", "ANVIL"),
        BEACON(14, "minecraft:beacon", "BEACON"),
        BREWING_STAND(14, "minecraft:brewing_stand", "BREWING"),
        ENCHANTMENT(14, "minecraft:enchanting_table", "ENCHANTING"),
        FURNACE(14, "minecraft:furnace", "FURNACE"),
        HOPPER(14, "minecraft:hopper", "HOPPER"),
        MERCHANT(14, "minecraft:villager", "MERCHANT"),
        // For an unknown reason, when updating a shulker box, the size of the inventory gets a little bigger.
        SHULKER_BOX(14, "minecraft:blue_shulker_box", "SHULKER_BOX"),

        // Added in 1.14, so only works with containers.
        BLAST_FURNACE(14, null, "BLAST_FURNACE"),
        CRAFTING(14, null, "WORKBENCH"),
        GRINDSTONE(14, null, "GRINDSTONE"),
        LECTERN(14, null, "LECTERN"),
        LOOM(14, null, "LOOM"),
        SMOKER(14, null, "SMOKER"),
        // CARTOGRAPHY in 1.14, CARTOGRAPHY_TABLE in 1.15 & 1.16 (container), handle in getObject().
        CARTOGRAPHY_TABLE(14, null, "CARTOGRAPHY"),
        STONECUTTER(14, null, "STONECUTTER"),

        // Added in 1.14, functional since 1.16.
        SMITHING(16, null, "SMITHING");

        // The version in which the inventory container was added.
        private final int containerVersion;

        // The name of the inventory from Minecraft for older versions.
        private final String minecraftName;

        // Inventory type names of the inventory.
        private final String[] inventoryTypeNames;

        private static final char[] ALPHABET = "abcdefghijklmnopqrstuvwxyz".toCharArray();

        Containers(int containerVersion, String minecraftName, String... inventoryTypeNames) {
            this.containerVersion = containerVersion;
            this.minecraftName = minecraftName;
            this.inventoryTypeNames = inventoryTypeNames;
        }

        /**
         * Get the container based on the current open inventory of the player.
         *
         * @param type type of inventory.
         * @return the container.
         */
        public static @Nullable Containers getType(InventoryType type, int size) {
            if (type == InventoryType.CHEST) {
                return Containers.valueOf("GENERIC_9X" + size / 9);
            }
            for (Containers container : Containers.values()) {
                for (String bukkitName : container.getInventoryTypeNames()) {
                    if (bukkitName.equalsIgnoreCase(type.toString())) {
                        return container;
                    }
                }
            }
            return null;
        }

        /**
         * Get the object from the container enum.
         *
         * @return a Containers object if 1.14+, otherwise, a String.
         */
        public @Nullable Object getObject() {
            try {
                if (!useContainers()) return getMinecraftName();
                int version = XReflection.MINOR_NUMBER;
                String name = (version == 14 && this == CARTOGRAPHY_TABLE) ? "CARTOGRAPHY" : name();
                // Since 1.17, containers go from "a" to "x".
                if (version > 16) name = String.valueOf(ALPHABET[ordinal()]);
                Field field = CONTAINERS.getField(name);
                return field.get(null);
            } catch (ReflectiveOperationException exception) {
                exception.printStackTrace();
            }
            return null;
        }
    }
}
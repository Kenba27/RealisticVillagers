plugins {
    java
    id("io.papermc.paperweight.userdev") version "2.0.0-beta.24"
}

// Phien ban plugin (phai trung voi <version> trong pom.xml).
val pluginVersion = "3.3.6.5"

// Jar cua module "core" do Maven build ra (da shade san), xem workflow build.yml.
val coreJar = layout.projectDirectory.file("core/target/realisticvillagers-core-$pluginVersion.jar")

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Paper 26.2 (unobfuscated, Mojang mappings). Bao gom ca Paper API + NMS.
    paperweight.paperDevBundle("26.2.build.+")

    compileOnly(files(coreJar))

    compileOnly("org.jetbrains:annotations:24.0.1")
    compileOnly("org.projectlombok:lombok:1.18.42")
    annotationProcessor("org.projectlombok:lombok:1.18.42")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

sourceSets {
    main {
        java.setSrcDirs(listOf("v26_2/src/main/java"))
        resources.setSrcDirs(emptyList<String>())
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.jar {
    // Gop core (da shade) + NMS 26.2 thanh 1 file plugin duy nhat.
    from(zipTree(coreJar)) {
        exclude("META-INF/**")
    }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    archiveBaseName.set("RealisticVillagers")
    archiveVersion.set("$pluginVersion-paper-26.2")
    archiveClassifier.set("")
    manifest {
        // Paper 26.1+ khong con remap Spigot -> chi dung Mojang mappings.
        attributes("paperweight-mappings-namespace" to "mojang")
    }
}

tasks.build {
    dependsOn(tasks.jar)
}

/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2021 Matsubara
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package me.matsubara.realisticvillagers.util;

import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryView;

import java.util.Set;

/**
 * Updates the title of the inventory a player has open.
 * Uses the Bukkit/Paper API only (no NMS reflection), so it works on any version.
 */
public final class InventoryUpdate {

    private static final Set<String> UNOPENABLES = Set.of("CRAFTING", "CREATIVE", "PLAYER");

    private InventoryUpdate() {
    }

    @SuppressWarnings("deprecation")
    public static void updateInventory(Player player, String newTitle) {
        if (player == null || newTitle == null) return;

        try {
            if (newTitle.length() > 32) newTitle = newTitle.substring(0, 32);

            InventoryView open = player.getOpenInventory();
            if (UNOPENABLES.contains(open.getType().name())) return;

            open.setTitle(newTitle);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }
}

package me.matsubara.realisticvillagers.nms.v26_2;

import net.minecraft.world.entity.EntityTypes;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.mojang.authlib.GameProfile;
import com.mojang.serialization.Codec;
import me.matsubara.realisticvillagers.RealisticVillagers;
import me.matsubara.realisticvillagers.data.LastKnownPosition;
import me.matsubara.realisticvillagers.data.serialization.OfflineDataWrapper;
import me.matsubara.realisticvillagers.entity.IVillagerNPC;
import me.matsubara.realisticvillagers.entity.v26_2.WanderingTraderNPC;
import me.matsubara.realisticvillagers.entity.v26_2.pet.PetCat;
import me.matsubara.realisticvillagers.entity.v26_2.pet.PetParrot;
import me.matsubara.realisticvillagers.entity.v26_2.pet.PetWolf;
import me.matsubara.realisticvillagers.entity.v26_2.pet.horse.PetDonkey;
import me.matsubara.realisticvillagers.entity.v26_2.pet.horse.PetHorse;
import me.matsubara.realisticvillagers.entity.v26_2.pet.horse.PetMule;
import me.matsubara.realisticvillagers.entity.v26_2.villager.OfflineVillagerNPC;
import me.matsubara.realisticvillagers.entity.v26_2.villager.VillagerNPC;
import me.matsubara.realisticvillagers.files.Config;
import me.matsubara.realisticvillagers.nms.INMSConverter;
import me.matsubara.realisticvillagers.util.PluginUtils;
import me.matsubara.realisticvillagers.util.Reflection;
import net.minecraft.core.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Keyframe;
import net.minecraft.util.KeyframeTrack;
import net.minecraft.world.attribute.AttributeTypes;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.gossip.GossipType;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.sensing.Sensor;
import net.minecraft.world.entity.ai.sensing.SensorType;
import net.minecraft.world.entity.animal.equine.Donkey;
import net.minecraft.world.entity.animal.equine.Horse;
import net.minecraft.world.entity.animal.equine.Mule;
import net.minecraft.world.entity.animal.feline.Cat;
import net.minecraft.world.entity.animal.parrot.Parrot;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.npc.villager.VillagerType;
import net.minecraft.world.entity.npc.wanderingtrader.WanderingTrader;
import net.minecraft.world.entity.schedule.Activity;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.entity.vehicle.minecart.Minecart;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.storage.RegionFile;
import net.minecraft.world.level.chunk.storage.RegionStorageInfo;
import net.minecraft.world.level.storage.PrimaryLevelData;
import net.minecraft.world.timeline.Timeline;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.craftbukkit.CraftRaid;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.entity.CraftLivingEntity;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.craftbukkit.entity.CraftVillager;
import org.bukkit.craftbukkit.persistence.CraftPersistentDataAdapterContext;
import org.bukkit.craftbukkit.persistence.CraftPersistentDataContainer;
import org.bukkit.craftbukkit.persistence.CraftPersistentDataTypeRegistry;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.Player;
import org.bukkit.entity.ZombieVillager;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MusicInstrumentMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

@SuppressWarnings("unchecked")
public class NMSConverter implements INMSConverter {

    private final RealisticVillagers plugin;
    private Holder<Timeline> babyTimeline;
    private Holder<Timeline> defaultTimeline;

    // Registry fields.
    private static final MethodHandle INSTRUSIVE_HOLDER_CACHE = Reflection.getField(MappedRegistry.class, Map.class, "m", false, "unregisteredIntrusiveHolders");
    private static final MethodHandle FROZEN = Reflection.getField(MappedRegistry.class, boolean.class, "l", false, "frozen");
    private static final MethodHandle ATTRIBUTES = Reflection.getField(AttributeMap.class, Map.class, "a", true, "attributes");

    // Constructors.
    private static final MethodHandle MEMORY_MODULE_TYPE = Reflection.getConstructor(MemoryModuleType.class, Optional.class);
    private static final MethodHandle SENSOR_TYPE = Reflection.getConstructor(SensorType.class, Supplier.class);
    private static final MethodHandle ACTIVITY;
    private static final boolean ACTIVITY_INT;

    private static final CraftPersistentDataTypeRegistry REGISTRY = new CraftPersistentDataTypeRegistry();
    private static final CraftPersistentDataAdapterContext ADAPTER_CONTEXT = new CraftPersistentDataAdapterContext(REGISTRY);

    private static final Map<String, Activity> ACTIVITIES;
    private static final FilenameFilter DATA_FILE_FILTER = (directory, name) -> new File(directory, name).isFile()
            && name.endsWith(".mca")
            && !name.contains("backup")
            && !name.contains("mcc");

    public static final Map<UUID, EnvironmentAttributeSystem> ENVIRONMENT_CACHE = new HashMap<>();

    static {
        MethodHandle temp = Reflection.getConstructor(false, Activity.class, String.class);
        ACTIVITY_INT = temp == null;
        ACTIVITY = ACTIVITY_INT ? Reflection.getConstructor(Activity.class, String.class, int.class) : temp;
        // RULE_CALLBACK = Reflection.getFieldRaw(GameRules.Type.class, BiConsumer.class, "c", "callback");

        Map<String, Activity> activities = new HashMap<>();
        for (Field field : Activity.class.getDeclaredFields()) {
            if (!field.getType().equals(Activity.class)) continue;

            try {
                Activity activity = (Activity) field.get(null);
                activities.put(activity.getName(), activity);
            } catch (IllegalAccessException ignored) {
            }
        }
        ACTIVITIES = Collections.unmodifiableMap(activities);
    }

    public NMSConverter(RealisticVillagers plugin) {
        this.plugin = plugin;
    }

    @Override
    public Optional<IVillagerNPC> getNPC(org.bukkit.entity.LivingEntity living) {
        return Optional.ofNullable(((CraftEntity) living).getHandle() instanceof IVillagerNPC npc ? npc : null);
    }

    private static boolean factoryLogged;

    // Find the "factory" field of EntityType by type, so it doesn't depend on the field name.
    private static @Nullable Field findFactoryField() {
        Field field = Reflection.getFieldRaw(EntityType.class, EntityType.EntityFactory.class, "factory");
        if (field != null) return field;

        for (Field declared : EntityType.class.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(declared.getModifiers())) continue;
            if (!declared.getType().equals(EntityType.EntityFactory.class)) continue;
            declared.setAccessible(true);
            return declared;
        }
        return null;
    }

    // Decide using the Bukkit world name, since the type of Level#getLevelData() changed in newer versions.
    private boolean isEnabledFor(Level level) {
        try {
            if (level instanceof ServerLevel server) {
                org.bukkit.World world = server.getWorld();
                if (world != null) return plugin.isEnabledIn(world.getName());
            }
            if (level.getLevelData() instanceof PrimaryLevelData data) {
                return plugin.isEnabledIn(data.getLevelName());
            }
        } catch (Throwable throwable) {
            plugin.getLogger().warning("Couldn't check if the world is enabled: " + throwable);
        }
        // Unknown level, enable by default.
        return true;
    }

    @Override
    public void registerEntities() {
        // "factory" field.
        Field field = findFactoryField();
        if (field == null) {
            plugin.getLogger().severe("Couldn't find the EntityType factory field! Custom villagers will NOT work.");
            return;
        }
        plugin.getLogger().info("Using EntityType field '" + field.getName() + "' to register custom entities.");

        Reflection.setFieldUsingUnsafe(
                field,
                EntityTypes.VILLAGER,
                (EntityType.EntityFactory<Villager>) (type, level) -> {
                    if (isEnabledFor(level)) {
                        if (!factoryLogged) {
                            factoryLogged = true;
                            plugin.getLogger().info("Custom villager factory is working (created VillagerNPC).");
                        }
                        return new VillagerNPC(EntityTypes.VILLAGER, level);
                    }
                    return new Villager(EntityTypes.VILLAGER, level);
                });
        Reflection.setFieldUsingUnsafe(
                field,
                EntityTypes.WANDERING_TRADER,
                (EntityType.EntityFactory<WanderingTrader>) (type, level) -> {
                    if (isEnabledFor(level)) {
                        return new WanderingTraderNPC(EntityTypes.WANDERING_TRADER, level);
                    }
                    return new WanderingTrader(EntityTypes.WANDERING_TRADER, level);
                });
        Reflection.setFieldUsingUnsafe(field, EntityTypes.DONKEY, (EntityType.EntityFactory<Donkey>) PetDonkey::new);
        Reflection.setFieldUsingUnsafe(field, EntityTypes.HORSE, (EntityType.EntityFactory<Horse>) PetHorse::new);
        Reflection.setFieldUsingUnsafe(field, EntityTypes.MULE, (EntityType.EntityFactory<Mule>) PetMule::new);
        Reflection.setFieldUsingUnsafe(field, EntityTypes.CAT, (EntityType.EntityFactory<Cat>) PetCat::new);
        Reflection.setFieldUsingUnsafe(field, EntityTypes.PARROT, (EntityType.EntityFactory<Parrot>) PetParrot::new);
        Reflection.setFieldUsingUnsafe(field, EntityTypes.WOLF, (EntityType.EntityFactory<Wolf>) PetWolf::new);
    }

    @SuppressWarnings("deprecation")
    public static Integer extractParrotVariant(@Nullable CompoundTag tag) {
        if (tag == null || tag.isEmpty()) return null;

        EntityType<?> type = tag.read("id", EntityType.CODEC).orElse(null);
        if (type != EntityTypes.PARROT) return null;

        return tag.read("Variant", Parrot.Variant.LEGACY_CODEC)
                .map(Enum::ordinal)
                .orElse(null);
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public String getNPCTag(org.bukkit.entity.LivingEntity entity, boolean isInfection) {
        if (entity instanceof AbstractVillager villager) {
            Optional<IVillagerNPC> optional = getNPC(villager);
            if (optional.isEmpty()) return null;

            IVillagerNPC npc = optional.get();
            if (npc instanceof VillagerNPC temp) {
                temp.setWasInfected(isInfection);
            }

            if (npc.getOffline() instanceof OfflineVillagerNPC offline) {
                byte[] primitive = RealisticVillagers.VILLAGER_DATA.toPrimitive(
                        offline.toOfflineDataWrapper(),
                        villager.getPersistentDataContainer().getAdapterContext());
                return Base64.getEncoder().encodeToString(primitive);
            }
        } else if (entity instanceof ZombieVillager) {
            PersistentDataContainer container = entity.getPersistentDataContainer();
            return container.getOrDefault(plugin.getZombieTransformKey(), PersistentDataType.STRING, "");
        }
        return null;
    }

    @Override
    public boolean isSeekGoatHorn(@NotNull ItemStack item) {
        return item.getItemMeta() instanceof MusicInstrumentMeta meta && MusicInstrument.SEEK_GOAT_HORN.equals(meta.getInstrument());
    }

    @Override
    public void createBaby(@NotNull Location location, String name, String sex, UUID motherUUID, Player father) {
        Preconditions.checkNotNull(location.getWorld());
        ServerLevel level = ((CraftWorld) location.getWorld()).getHandle();

        VillagerNPC baby = new VillagerNPC(
                EntityTypes.VILLAGER,
                level,
                VillagerType.byBiome(level.getBiome(((CraftBlock) location.getBlock()).getPosition())));

        loadDataFromTag(baby.getBukkitEntity(), "");
        baby.setVillagerName(name);
        baby.setSex(sex);

        baby.setAge(-24000);
        baby.setPos(location.getX(), location.getY(), location.getZ());
        baby.setYRot(0.0f);
        baby.setXRot(0.0f);

        // Shouldn't be null unless the mother is dead.
        IVillagerNPC mother = plugin.getTracker().getOffline(motherUUID);
        if (mother != null) {
            org.bukkit.entity.LivingEntity bukkitMother = plugin.getUnloadedOffline(mother);

            VillagerNPC nmsMother = bukkitMother != null ? ((VillagerNPC) ((CraftVillager) bukkitMother).getHandle()) : null;
            if (nmsMother != null) {
                nmsMother.setAge(6000);
                nmsMother.getChildrens().add(baby.getOffline());
                baby.setMother(nmsMother.getOffline());
            }
        }

        UUID fatherUUID = father.getUniqueId();
        baby.setFather(fatherUUID, false);

        CustomGossipContainer gossips = baby.getGossips();
        for (GossipType type : GossipType.values()) {
            gossips.remove(type);
        }

        int reputation = Math.min(Config.INITIAL_REPUTATION_AT_BIRTH.asInt(), 75);
        if (reputation > 1) gossips.add(fatherUUID, GossipType.MINOR_POSITIVE, reputation);

        level.addFreshEntityWithPassengers(baby, CreatureSpawnEvent.SpawnReason.BREEDING);
        level.broadcastEntityEvent(baby, (byte) 12);
    }

    @Override
    public void loadDataFromTag(org.bukkit.entity.LivingEntity living, @NotNull String tag) {
        Optional<IVillagerNPC> npc = getNPC(living);
        if (npc.isEmpty()) return;

        if (npc.get() instanceof VillagerNPC temp) {
            handleTagLoad(living, tag, temp::loadFromOffline);
        } else if (npc.get() instanceof WanderingTraderNPC temp) {
            handleTagLoad(living, tag, temp::loadFromOffline);
        }
    }

    private void handleTagLoad(org.bukkit.entity.LivingEntity living, @NotNull String tag, Consumer<OfflineVillagerNPC> consumer) {
        if (tag.isEmpty()) {
            consumer.accept(OfflineVillagerNPC.DUMMY_OFFLINE);
            return;
        }

        OfflineDataWrapper wrapper = RealisticVillagers.villagerDataFromPrimitive(
                Base64.getDecoder().decode(tag),
                living.getPersistentDataContainer().getAdapterContext());

        consumer.accept(OfflineVillagerNPC.fromOfflineDataWrapper(wrapper) instanceof OfflineVillagerNPC temp ?
                temp :
                OfflineVillagerNPC.DUMMY_OFFLINE);
    }

    @Override
    public UUID getPartnerUUIDFromPlayerNBT(File file) {
        try (FileInputStream stream = new FileInputStream(file)) {
            CompoundTag tag = NbtIo.readCompressed(stream, NbtAccounter.unlimitedHeap());
            CompoundTag bukkit = getOrCreateBukkitTag(tag);
            return bukkit.getIntArray(plugin.getMarriedWith().toString()).map(UUIDUtil::uuidFromIntArray).orElse(null);
        } catch (IOException exception) {
            return null;
        }
    }

    @Override
    public void removePartnerFromPlayerNBT(File file) {
        try (FileInputStream stream = new FileInputStream(file)) {
            CompoundTag tag = NbtIo.readCompressed(stream, NbtAccounter.unlimitedHeap());

            CompoundTag bukkit = getOrCreateBukkitTag(tag);
            bukkit.remove(plugin.getMarriedWith().toString());

            if (bukkit.isEmpty()) {
                tag.remove("BukkitValues");
            } else {
                tag.put("BukkitValues", bukkit);
            }

            NbtIo.writeCompressed(tag, file.toPath());
        } catch (IOException exception) {
            plugin.getLogger().warning("Error loading player data!");
        }
    }

    @Override
    public void loadData() {
        File root = plugin.getServer().getWorldContainer();

        File[] worlds = root.listFiles(file -> {
            String[] files;
            return file.isDirectory()
                    && (files = file.list()) != null
                    && ArrayUtils.contains(files, "level.dat");
        });

        if (worlds == null) return;

        for (File world : worlds) {
            File entitiesFolder = new File(world, "entities");

            File[] entitiesFiles = entitiesFolder.listFiles(DATA_FILE_FILTER);
            if (entitiesFiles == null) continue;

            // Iterate through all .mca files in "entities" folder.
            for (File entityFile : entitiesFiles) {
                checkMCAFile(entityFile);
            }
        }
    }

    @Override
    public Raid getRaidAt(@NotNull Location location) {
        if (location.getWorld() == null) return null;

        BlockPos pos = BlockPos.containing(location.getX(), location.getY(), location.getZ());

        ServerLevel level = ((CraftWorld) location.getWorld()).getHandle();
        net.minecraft.world.entity.raid.Raid raid = level.getRaidAt(pos);

        return raid != null ? new CraftRaid(raid, level) : null;
    }

    public static void updateTamedData(@NotNull RealisticVillagers plugin, @NotNull LivingEntity living, boolean tamedByVillager) {
        CraftPersistentDataContainer container = living.getBukkitEntity().getPersistentDataContainer();
        container.set(plugin.getTamedByVillagerKey(), PersistentDataType.BOOLEAN, tamedByVillager);
        container.remove(plugin.getTamedByPlayerKey()); // Remove previous key, not used anymore.
    }

    @Override
    public GameProfile getPlayerProfile(Player player) {
        return ((CraftPlayer) player).getHandle().getGameProfile();
    }

    @Override
    public void refreshSchedules() {
        babyTimeline = createTimeline("baby");
        defaultTimeline = createTimeline("default");
    }

    @Override
    public IVillagerNPC getNPCFromTag(String tag) {
        return OfflineVillagerNPC.fromOfflineDataWrapper(RealisticVillagers.villagerDataFromPrimitive(
                Base64.getDecoder().decode(tag),
                ADAPTER_CONTEXT));
    }

    @Override
    public void spawnFromTag(@NotNull Location location, String tag) {
        Preconditions.checkArgument(location.getWorld() != null && !tag.isEmpty(), "Either world is null or tag is empty!");

        IVillagerNPC npc = plugin.getConverter().getNPCFromTag(tag);
        boolean trader = npc != null && npc.isWanderingTrader();

        ServerLevel level = ((CraftWorld) location.getWorld()).getHandle();
        net.minecraft.world.entity.npc.villager.AbstractVillager villager = trader ?
                new WanderingTraderNPC(EntityTypes.WANDERING_TRADER, level) :
                new VillagerNPC(EntityTypes.VILLAGER, level);

        loadDataFromTag((CraftLivingEntity) villager.getBukkitEntity(), tag);

        for (String effectString : Config.REVIVE_SPAWN_VALUES_POTION_EFFECTS.asStringList()) {
            if (Strings.isNullOrEmpty(effectString)) continue;
            String[] data = PluginUtils.splitData(effectString);

            PotionEffectType type = org.bukkit.Registry.EFFECT.get(NamespacedKey.minecraft(data[0].toLowerCase(Locale.ROOT)));
            if (type != null) {
                // Default = 5 seconds, level 1 (amplifier 0).
                int duration = data.length > 1 ? PluginUtils.getRangedAmount(data[1]) : 100;
                int amplifier = data.length > 2 ? PluginUtils.getRangedAmount(data[2]) - 1 : 0;
                ((CraftLivingEntity) villager.getBukkitEntity())
                        .addPotionEffect(new PotionEffect(type, duration, amplifier));
            }
        }

        villager.setPos(location.getX(), location.getY(), location.getZ());
        villager.setYRot(location.getYaw());
        villager.setXRot(0.0f);

        float health = (float) Math.min(villager.getMaxHealth(), Config.REVIVE_SPAWN_VALUES_HEALTH.asDouble());
        villager.setHealth(health);

        int foodLevel = Math.min(20, Config.REVIVE_SPAWN_VALUES_FOOD_LEVEL.asInt());

        if (villager instanceof VillagerNPC temp) {
            temp.setFoodLevel(foodLevel);
            temp.setRevivingTicks(60);
        }

        level.addFreshEntity(villager, CreatureSpawnEvent.SpawnReason.DEFAULT);
    }

    @Override
    public void addGameRuleListener(@NotNull World world) {
        // There's no way to do this on newer versions (Spigot). For Paper, we'll use PaperListeners.
        // We'll take advantage of this method to create environment instances for worlds.

        EnvironmentAttributeSystem.Builder builder = EnvironmentAttributeSystem.builder();
        ServerLevel level = ((CraftWorld) world).getHandle();

        if (babyTimeline != null) builder.addTimelineLayer(babyTimeline, level.clockManager());
        if (defaultTimeline != null) builder.addTimelineLayer(defaultTimeline, level.clockManager());

        ENVIRONMENT_CACHE.put(world.getUID(), builder.build());
    }

    private @Nullable Holder<Timeline> createTimeline(@NotNull String name) {
        try {
            EnvironmentAttribute<Activity> schedule = name.equals("baby") ? VillagerNPC.VILLAGER_BABY : VillagerNPC.VILLAGER_DEFAULT;

            ConfigurationSection section = plugin.getConfig().getConfigurationSection("schedules." + name);
            if (section == null) return null;

            KeyframeTrack.Builder<Activity> trackBuilder = new KeyframeTrack.Builder<>();
            for (int time : section.getKeys(false).stream()
                    .filter(NumberUtils::isCreatable)
                    .map(Integer::valueOf)
                    .sorted()
                    .toList()) {
                Activity activity = ACTIVITIES.get(plugin.getConfig().getString("schedules." + name + "." + time, "").toLowerCase(Locale.ROOT));
                if (activity != null) trackBuilder.addKeyframe(time, activity);
            }

            return Holder.direct(Timeline.builder(net.minecraft.server.MinecraftServer.getServer().registryAccess().getOrThrow(net.minecraft.world.clock.WorldClocks.OVERWORLD))
                    .setPeriodTicks(24000)
                    .addTrack(schedule, (builder) -> {
                        for (Keyframe<Activity> frame : trackBuilder.build().keyframes()) {
                            builder.addKeyframe(frame.ticks(), frame.value());
                        }
                    })
                    .build());
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }

    private void checkMCAFile(@NotNull File entityFile) {
        try {
            String world = entityFile.getParentFile().getParentFile().getName();

            ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, Identifier.withDefaultNamespace(world.toLowerCase(Locale.ENGLISH)));
            RegionStorageInfo storage = new RegionStorageInfo(world, key, "entities");

            RegionFile region = new RegionFile(storage, entityFile.toPath(), entityFile.getParentFile().toPath(), false);

            for (int x = 0; x < 32; x++) {
                for (int z = 0; z < 32; z++) {
                    checkRegion(region, world, x, z);
                }
            }

            region.close();
        } catch (IOException | IllegalArgumentException ignored) {
            // Invalid region file, caused by the server software in most of the cases; ignoring to prevent spam.
        }
    }

    private void checkRegion(@NotNull RegionFile region, String world, int x, int z) throws IOException {
        ChunkPos chunkPos = new ChunkPos(x, z);
        if (!region.hasChunk(chunkPos)) return;

        DataInputStream stream = region.getChunkDataInputStream(chunkPos);
        if (stream == null) return;

        CompoundTag chunkTag = NbtIo.read(stream);

        stream.close();

        for (Tag tag : chunkTag.getListOrEmpty("Entities")) {
            if (!(tag instanceof CompoundTag compound)) continue;
            if (!compound.getString("id").map(id -> id.equals("minecraft:villager")).orElse(false)) continue;

            UUID uuid = compound.getIntArray("UUID").map(UUIDUtil::uuidFromIntArray).orElse(null);
            if (uuid == null) continue;

            CompoundTag bukkit = getOrCreateBukkitTag(compound);

            Tag values = bukkit.get(plugin.getNpcValuesKey().toString());
            if (values == null) continue;

            ListTag pos = compound.getListOrEmpty("Pos");
            double xc = pos.getDoubleOr(0, 0.0d);
            double yc = pos.getDoubleOr(1, 0.0d);
            double zc = pos.getDoubleOr(2, 0.0d);

            Set<IVillagerNPC> offlines = plugin.getTracker().getOfflineVillagers();
            if (offlines.stream().anyMatch(npc -> npc.getUniqueId().equals(uuid))) continue;

            try {
                byte[] primitive = REGISTRY.extract(RealisticVillagers.VILLAGER_DATA, values);
                OfflineDataWrapper wrapper = RealisticVillagers.villagerDataFromPrimitive(primitive, ADAPTER_CONTEXT);
                OfflineVillagerNPC offline = OfflineVillagerNPC.fromOfflineDataWrapper(wrapper) instanceof OfflineVillagerNPC temp ?
                        temp :
                        OfflineVillagerNPC.DUMMY_OFFLINE;
                offline.setLastKnownPosition(new LastKnownPosition(world, xc, yc, zc));
                offlines.add(offline);
            } catch (Exception ignored) {
            }
        }
    }

    public static <T> void unfreezeRegistry(Registry<T> registry) {
        Preconditions.checkNotNull(INSTRUSIVE_HOLDER_CACHE);
        Preconditions.checkNotNull(FROZEN);

        try {
            INSTRUSIVE_HOLDER_CACHE.invoke(registry, null);
            FROZEN.invoke(registry, false);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public static <T> T register(Registry<? super T> registry, String name, T value) {
        unfreezeRegistry(registry);
        try {
            return Registry.register(registry, Identifier.fromNamespaceAndPath("realisticvillagers", name), value);
        } finally {
            if (FROZEN != null) {
                try {
                    FROZEN.invoke(registry, true);
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                }
            }
        }
    }

    @SuppressWarnings("unused")
    public static EnvironmentAttribute<Activity> registerEnvironmentAttribute(String name) {
        EnvironmentAttribute<Activity> attribute = EnvironmentAttribute
                .builder(AttributeTypes.ACTIVITY)
                .defaultValue(Activity.IDLE)
                .build();
        return register(BuiltInRegistries.ENVIRONMENT_ATTRIBUTE, name, attribute);
    }

    public static <U> MemoryModuleType<U> registerMemoryType(String name) {
        return registerMemoryType(name, null);
    }

    public static <U> @Nullable MemoryModuleType<U> registerMemoryType(String name, Codec<U> codec) {
        Preconditions.checkNotNull(MEMORY_MODULE_TYPE);
        try {
            return register(BuiltInRegistries.MEMORY_MODULE_TYPE, name, (MemoryModuleType<U>) MEMORY_MODULE_TYPE.invoke(Optional.ofNullable(codec)));
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }

    public static <U extends Sensor<?>> @Nullable SensorType<U> registerSensor(String name, Supplier<U> sensor) {
        Preconditions.checkNotNull(SENSOR_TYPE);
        try {
            return register(BuiltInRegistries.SENSOR_TYPE, name, (SensorType<U>) SENSOR_TYPE.invoke(sensor));
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }

    public static @Nullable Activity registerActivity(String name) {
        Preconditions.checkNotNull(ACTIVITY);
        try {
            Activity activity = (Activity) (ACTIVITY_INT ? ACTIVITY.invoke(name, 0) : ACTIVITY.invoke(name));
            return register(BuiltInRegistries.ACTIVITY, name, activity);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }

    public static void registerAttribute(LivingEntity entity, Holder<Attribute> attribute, double value) {
        Preconditions.checkNotNull(ATTRIBUTES);
        try {
            Map<Holder<Attribute>, AttributeInstance> attributes = (Map<Holder<Attribute>, AttributeInstance>) ATTRIBUTES.invoke(entity.getAttributes());
            if (attributes == null) return;

            @SuppressWarnings("ResultOfMethodCallIgnored") Consumer<AttributeInstance> onDirty = AttributeInstance::getAttribute;
            attributes.put(attribute, new AttributeInstance(attribute, onDirty));

            AttributeInstance instance = entity.getAttribute(attribute);
            if (instance != null) instance.setBaseValue(value);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public static CompoundTag getOrCreateBukkitTag(@NotNull CompoundTag base) {
        return base.get("BukkitValues") instanceof CompoundTag tag ? tag : new CompoundTag();
    }

    public static void leaveVehicle(@NotNull Entity entity) {
        Entity vehicle = entity.getVehicle();
        if (vehicle != null
                && !(vehicle instanceof AbstractBoat)
                && !(vehicle instanceof Minecart)) {
            entity.stopRiding();
        }
    }
}